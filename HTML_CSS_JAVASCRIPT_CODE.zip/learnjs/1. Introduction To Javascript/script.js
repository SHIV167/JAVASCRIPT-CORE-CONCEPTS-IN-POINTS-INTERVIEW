let c = 12;
let d = 13; 

let age = 26; // initialisation

const name = 'Anuj';
const Name = "kumar";

// console.log('age', age)
// age = 28;

// console.log("c+d is", c + d);

// console.log('age', age)
console.log('name', name);


