// import { mul, add } from "./utility.js";
// import * as utility from './utility.js';

import add from "./utility.js";


const result = add(2, 3, 4);

console.log(result);
// console.log(utility.STUDENTS_COUNT);