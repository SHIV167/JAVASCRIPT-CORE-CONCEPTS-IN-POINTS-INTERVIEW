function multiply(a, b, c) {
    return a*b*c;
}

export default function addition(a, b, c) {
    return a+b+c;
}

export const STUDENTS_COUNT = 23;

export {
    multiply as mul,
}