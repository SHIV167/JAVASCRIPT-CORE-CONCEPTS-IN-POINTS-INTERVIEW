let a = 23;
// a = a+ 1;

// console.log(a);

// a = a+ 1;

// console.log(a);

// a = false

a = Boolean(a);

console.log("the value of a is", a);
console.log("the type of a is", typeof a);

let b = undefined;
b = Number(b);

console.log("b is ", b);
