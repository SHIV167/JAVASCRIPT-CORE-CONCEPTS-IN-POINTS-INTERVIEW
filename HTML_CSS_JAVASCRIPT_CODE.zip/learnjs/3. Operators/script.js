const firstNumber = false;
const secondNumber = true;

// const result = firstNumber + secondNumber;
// const result = firstNumber % secondNumber;
const result = firstNumber || secondNumber;

console.log(!secondNumber);

// console.log(result);

// 3 = 0*4 + 3

// let thirdNumber = 12;
// thirdNumber **= 4; // thirdNumber = thirdNumber + 4;

// console.log(result);
