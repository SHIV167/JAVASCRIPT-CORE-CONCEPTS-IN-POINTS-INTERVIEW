// const age = 4;

// if (age >= 18) {
//     console.log("you are inside if");
//     console.log("you can vote");

//     if (age > 60) {
//         console.log("you can vote again");
//     }
// } else {
//     console.log("you cannot vote");

//     if (age < 5) {
//         console.log("you must go to the school");

//     }
// }

// console.log("this will execute always");

// const marks = 92;

// if (marks > 90) {
//     console.log("A+");
// } else if (marks > 80) {
//     console.log("A");
// } else if (marks > 70) {
//     console.log("B+");
// } else if (marks > 60) {
//     console.log("B");
// } else {
//     console.log("Low marks");
// }

const marks = 10;

// const result = marks >= 40 ? "PASSED" : "FAILED";

let result = "";
if (marks >= 40) {
    result = "PASSED";
} else {
    result = "FAILED";
}

result = "HAHA";

console.log("result", result);
